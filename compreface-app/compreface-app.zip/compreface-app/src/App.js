
import './App.css';

import {useRef} from 'react';

function App() {
  const videoTag = useRef('null');
  const handleVideoStart= () =>{

   navigator.mediaDevices.getUserMedia({video:true})
   .then(res => videoTag.current.srcObject = res)
   .catch(error =>console.error(error))

  }

  return (
    <div className="App">
      <header className="App-header">
        <video ref={videoTag} width="640" height="480" autoPlay muted></video>
        <canvas width="640" height="480" style={{display:'none'}}></canvas>
        <canvas width="640" height="480" style={{position:'absolute'}}></canvas>
       <button onClick={handleVideoStart}>start button</button>
      </header>
    </div>
  );
}

export default App;
